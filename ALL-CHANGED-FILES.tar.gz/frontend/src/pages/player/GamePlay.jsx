import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { gameAPI, walletAPI } from '../../services/api';

// CasinoPlus-style symbol definitions
const SYMBOL_ICONS = {
  wild: '👑', scatter: '💎', seven: '7️⃣', bar: '🍫', bell: '🔔',
  cherry: '🍒', lemon: '🍋', orange: '🍊', plum: '🍇', grape: '🫐'
};

const SYMBOL_COLORS = {
  wild: '#FFD700', scatter: '#00D9FF', seven: '#FF1493', bar: '#CD7F32', bell: '#FFD700',
  cherry: '#FF1493', lemon: '#FFFF00', orange: '#FF8C00', plum: '#9932CC', grape: '#8B008B'
};

// Game-specific gradient backgrounds (matching game thumbnails)
const GAME_THEMES = {
  'fortune-tiger': { bg: 'linear-gradient(135deg, #FF6B35 0%, #F7931E 50%, #FFD700 100%)', accent: '#FF6B35' },
  'fortune-ox': { bg: 'linear-gradient(135deg, #C41E3A 0%, #8B0000 50%, #FFD700 100%)', accent: '#C41E3A' },
  'fortune-mouse': { bg: 'linear-gradient(135deg, #FF69B4 0%, #FF1493 50%, #C71585 100%)', accent: '#FF69B4' },
  'gates-of-olympus': { bg: 'linear-gradient(135deg, #4B0082 0%, #8B008B 50%, #FFD700 100%)', accent: '#4B0082' },
  'starlight-princess': { bg: 'linear-gradient(135deg, #FF69B4 0%, #FFB6C1 50%, #FFD700 100%)', accent: '#FF69B4' },
  'sweet-bonanza': { bg: 'linear-gradient(135deg, #FF69B4 0%, #FFB6C1 50%, #FFD700 100%)', accent: '#FF69B4' },
  'wild-bandito': { bg: 'linear-gradient(135deg, #8B4513 0%, #D2691E 50%, #FFD700 100%)', accent: '#8B4513' },
  'mahjong-ways': { bg: 'linear-gradient(135deg, #DC143C 0%, #B22222 50%, #FFD700 100%)', accent: '#DC143C' },
  'mahjong-ways-2': { bg: 'linear-gradient(135deg, #DC143C 0%, #B22222 50%, #FFD700 100%)', accent: '#DC143C' },
  'dragon-legend': { bg: 'linear-gradient(135deg, #FF4500 0%, #FF6347 50%, #FFD700 100%)', accent: '#FF4500' },
  'lucky-neko': { bg: 'linear-gradient(135deg, #FF69B4 0%, #FFB6C1 50%, #FFD700 100%)', accent: '#FF69B4' },
  'bali-vacation': { bg: 'linear-gradient(135deg, #00CED1 0%, #40E0D0 50%, #FFD700 100%)', accent: '#00CED1' },
  'caishen-wins': { bg: 'linear-gradient(135deg, #FF0000 0%, #DC143C 50%, #FFD700 100%)', accent: '#FF0000' },
  'double-fortune': { bg: 'linear-gradient(135deg, #FF1493 0%, #C71585 50%, #FFD700 100%)', accent: '#FF1493' },
  'gem-saviour': { bg: 'linear-gradient(135deg, #9370DB 0%, #8A2BE2 50%, #FFD700 100%)', accent: '#9370DB' },
  'dragon-fortune': { bg: 'linear-gradient(135deg, #FF4500 0%, #FF6347 50%, #FFD700 100%)', accent: '#FF4500' },
  'default': { bg: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)', accent: '#FFD700' }
};

// Audio context for sound effects
const createAudioContext = () => {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  return new AudioContext();
};

let audioContext = null;

const playSpinSound = () => {
  if (!audioContext) audioContext = createAudioContext();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();
  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);
  oscillator.type = 'sine';
  oscillator.frequency.setValueAtTime(200, audioContext.currentTime);
  oscillator.frequency.exponentialRampToValueAtTime(800, audioContext.currentTime + 0.1);
  oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.2);
  gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
  oscillator.start(audioContext.currentTime);
  oscillator.stop(audioContext.currentTime + 0.2);
};

const playReelStopSound = () => {
  if (!audioContext) audioContext = createAudioContext();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();
  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);
  oscillator.type = 'triangle';
  oscillator.frequency.setValueAtTime(550, audioContext.currentTime);
  oscillator.frequency.exponentialRampToValueAtTime(220, audioContext.currentTime + 0.1);
  gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
  oscillator.start(audioContext.currentTime);
  oscillator.stop(audioContext.currentTime + 0.1);
};

const playWinSound = () => {
  if (!audioContext) audioContext = createAudioContext();
  const notes = [523.25, 659.25, 783.99, 1046.50];
  notes.forEach((freq, i) => {
    setTimeout(() => {
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.25, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    }, i * 100);
  });
};

const playJackpotSound = () => {
  if (!audioContext) audioContext = createAudioContext();
  for (let i = 0; i < 8; i++) {
    setTimeout(() => {
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      oscillator.type = 'square';
      oscillator.frequency.setValueAtTime(400 + (i * 100), audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.15);
    }, i * 80);
  }
};

export default function GamePlay() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [game, setGame] = useState(null);
  const [grid, setGrid] = useState(null);
  const [displayGrid, setDisplayGrid] = useState(null);
  const [bet, setBet] = useState(10);
  const [balance, setBalance] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [spinProgress, setSpinProgress] = useState({});
  const [lastWin, setLastWin] = useState(0);
  const [freeSpins, setFreeSpins] = useState(0);
  const [message, setMessage] = useState('');
  const [winningSymbols, setWinningSymbols] = useState([]);
  const [jackpotWon, setJackpotWon] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [bigWin, setBigWin] = useState(false);
  const [gameType, setGameType] = useState('slots');
  const [showPaytable, setShowPaytable] = useState(false);

  const spinningSymbols = useRef(null);

  const getGameTheme = useCallback(() => {
    if (!slug) return GAME_THEMES['default'];
    const gameSlug = slug.toLowerCase();
    for (const [key, theme] of Object.entries(GAME_THEMES)) {
      if (gameSlug.includes(key)) return theme;
    }
    return GAME_THEMES['default'];
  }, [slug]);

  const gameTheme = getGameTheme();

  useEffect(() => {
    walletAPI.balance().then(({ data }) => setBalance(Number(data.balance) || 0)).catch(() => {});
    gameAPI.details(slug).then(({ data }) => {
      setGame(data);
      setGameType(data.type || 'slots');
      setBet(Number(data.min_bet));
      setDisplayGrid(Array(5).fill(null).map(() =>
        Array(3).fill(null).map(() => ({ id: 'cherry', name: 'Cherry' }))
      ));
    }).catch(() => navigate('/'));
  }, [slug, navigate]);

  useEffect(() => {
    if (spinning) {
      const symbols = ['cherry', 'lemon', 'orange', 'seven', 'bell', 'bar', 'wild', 'scatter', 'grape', 'plum'];
      spinningSymbols.current = setInterval(() => {
        setDisplayGrid(Array(5).fill(null).map(() =>
          Array(3).fill(null).map(() => ({
            id: symbols[Math.floor(Math.random() * symbols.length)],
            name: ''
          }))
        ));
      }, 80);
    } else {
      if (spinningSymbols.current) clearInterval(spinningSymbols.current);
    }
    return () => {
      if (spinningSymbols.current) clearInterval(spinningSymbols.current);
    };
  }, [spinning]);

  const triggerConfetti = () => {
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 4000);
  };

  const quickBets = [10, 50, 100, 500, 1000];

  const animateReels = async (finalGrid) => {
    const REEL_DELAY = 250;
    playSpinSound();
    setSpinProgress({ 0: true, 1: true, 2: true, 3: true, 4: true });
    for (let i = 0; i < 5; i++) {
      await new Promise(r => setTimeout(r, REEL_DELAY));
      playReelStopSound();
      setSpinProgress(prev => ({ ...prev, [i]: false }));
    }
    setGrid(finalGrid);
    setDisplayGrid(finalGrid);
  };

  const spin = async () => {
    if (spinning) return;
    setSpinning(true);
    setLastWin(0);
    setMessage('');
    setWinningSymbols([]);
    setJackpotWon(false);
    setBigWin(false);

    try {
      const { data } = await gameAPI.spin(game.id, bet);
      await animateReels(data.grid);
      setBalance(data.balance);
      setLastWin(data.totalWin);

      if (data.totalWin > 0) {
        playWinSound();
        if (data.totalWin >= bet * 25) {
          setBigWin(true);
          triggerConfetti();
          setMessage(`BIG WIN! ₱${data.totalWin.toLocaleString()}`);
        } else if (data.totalWin >= bet * 10) {
          setBigWin(true);
          setMessage(`NICE WIN! ₱${data.totalWin.toLocaleString()}`);
        } else {
          setMessage(`You won ₱${data.totalWin.toLocaleString()}`);
        }
        // Highlight only winning payline positions
        if (data.paylineWins && data.paylineWins.length > 0 && data.grid) {
          const PAYLINES = [
            [1,1,1,1,1],[0,0,0,0,0],[2,2,2,2,2],[0,1,2,1,0],[2,1,0,1,2],
            [0,0,1,2,2],[2,2,1,0,0],[1,0,0,0,1],[1,2,2,2,1],[0,1,1,1,0],
            [2,1,1,1,2],[1,0,1,0,1],[1,2,1,2,1],[0,1,0,1,0],[2,1,2,1,2],
            [1,1,0,1,1],[1,1,2,1,1],[0,0,1,0,0],[2,2,1,2,2],[0,2,0,2,0]
          ];
          const winPositions = new Set();
          data.paylineWins.forEach(w => {
            const payline = PAYLINES[w.payline];
            if (payline) {
              for (let col = 0; col < w.count; col++) {
                winPositions.add(`${col}-${payline[col]}`);
              }
            }
          });
          setWinningSymbols([...winPositions]);
        } else {
          setWinningSymbols([]);
        }
      }
      if (data.freeSpinsAwarded > 0) {
        setFreeSpins(prev => prev + data.freeSpinsAwarded);
        setMessage(prev => prev + ` +${data.freeSpinsAwarded} Free Spins!`);
      }
      if (data.jackpotWon) {
        setJackpotWon(true);
        playJackpotSound();
        triggerConfetti();
        setMessage(`JACKPOT!!! ₱${data.jackpotWon.toLocaleString()}`);
      }
    } catch (err) {
      setMessage(err.response?.data?.error || 'Spin failed');
    }
    setTimeout(() => setSpinning(false), 300);
  };

  const useFreeSpin = async () => {
    if (spinning) return;
    setSpinning(true);
    setLastWin(0);
    setMessage('');
    setJackpotWon(false);

    try {
      const { data } = await gameAPI.freeSpin(game.id);
      await animateReels(data.grid);
      setGrid(data.grid);
      setDisplayGrid(data.grid);
      setBalance(data.balance);
      setLastWin(data.totalWin);
      setFreeSpins(data.freeSpinsRemaining);
      if (data.totalWin > 0) {
        playWinSound();
        setMessage(`Free spin win: ₱${data.totalWin.toLocaleString()}`);
        if (data.totalWin >= bet * 25) triggerConfetti();
      }
    } catch (err) {
      setMessage(err.response?.data?.error || 'Free spin failed');
      // Do not wipe free spins on network/API error — only clear if server says none left
      if (err.response?.status === 400) {
        setFreeSpins(0);
      }
    }
    setTimeout(() => setSpinning(false), 300);
  };

  if (!game) return <div className="loading"><div className="spinner" /></div>;

  const isSlotGame = gameType === 'slots';

  return (
    <div className="game-page" style={{
      background: 'linear-gradient(180deg, #0D0D1A 0%, #1A1A2E 50%, #0D0D1A 100%)',
      minHeight: '100vh',
      padding: '16px'
    }}>
      {/* Confetti */}
      {showConfetti && <Confetti />}

      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '16px',
        padding: '12px 16px',
        background: 'rgba(255, 255, 255, 0.05)',
        borderRadius: '12px',
        border: '1px solid rgba(255, 215, 0, 0.2)'
      }}>
        <button
          onClick={() => navigate('/')}
          style={{
            background: 'linear-gradient(135deg, #FFD700, #B8860B)',
            border: 'none',
            borderRadius: '8px',
            padding: '8px 16px',
            color: '#1A1A2E',
            fontWeight: '700',
            fontSize: '14px',
            cursor: 'pointer'
          }}
        >
          Back
        </button>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '10px', color: '#888', textTransform: 'uppercase' }}>Balance</div>
          <div style={{ fontSize: '18px', fontWeight: '800', color: '#FFD700' }}>
            ₱{Number(balance).toLocaleString('en', { minimumFractionDigits: 2 })}
          </div>
        </div>
      </div>

      {/* Game Header */}
      <div style={{ textAlign: 'center', marginBottom: '16px' }}>
        <h2 style={{
          fontSize: '24px',
          fontWeight: '900',
          background: 'linear-gradient(135deg, #FFD700, #FFA500)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          marginBottom: '8px'
        }}>
          {game.name}
        </h2>
        <div style={{ display: 'flex', justifyContent: 'center', gap: '12px' }}>
          <span style={{
            padding: '4px 12px',
            background: 'rgba(255, 215, 0, 0.1)',
            borderRadius: '20px',
            fontSize: '12px',
            color: '#FFD700',
            border: '1px solid rgba(255, 215, 0, 0.3)'
          }}>
            RTP {game.rtp}%
          </span>
          <span style={{
            padding: '4px 12px',
            background: 'rgba(255, 255, 255, 0.1)',
            borderRadius: '20px',
            fontSize: '12px',
            color: '#FFF'
          }}>
            ₱{game.min_bet} - ₱{game.max_bet}
          </span>
        </div>
      </div>

      {/* Slot Machine Frame */}
      <div style={{
        position: 'relative',
        padding: '6px',
        background: gameTheme.bg,
        borderRadius: '16px',
        marginBottom: '16px',
        boxShadow: `0 0 30px ${gameTheme.accent}40`
      }}>
        <div style={{
          padding: '3px',
          background: '#0D0D1A',
          borderRadius: '13px'
        }}>
          <div style={{
            padding: '16px 8px',
            background: 'linear-gradient(180deg, #0D0D1A 0%, #1A1A2E 50%, #0D0D1A 100%)',
            borderRadius: '10px',
            position: 'relative'
          }}>
            {/* Payline indicator */}
            <div style={{
              position: 'absolute',
              top: '50%',
              left: '8px',
              right: '8px',
              height: '2px',
              background: 'linear-gradient(90deg, transparent, rgba(255, 215, 0, 0.5), transparent)',
              transform: 'translateY(-50%)',
              zIndex: 1
            }} />

            {/* Reels */}
            <div style={{
              display: 'flex',
              justifyContent: 'center',
              gap: '6px',
              position: 'relative',
              zIndex: 2
            }}>
              {displayGrid && displayGrid.map((col, ci) => (
                <div key={ci} style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '6px',
                  padding: '6px 3px',
                  background: 'rgba(0, 0, 0, 0.3)',
                  borderRadius: '8px'
                }}>
                  {col.map((sym, ri) => {
                    const isSpinning = spinProgress[ci];
                    const isWinning = winningSymbols.includes(`${ci}-${ri}`) && !isSpinning;
                    const symbolColor = SYMBOL_COLORS[sym.id] || '#FFD700';

                    return (
                      <div
                        key={`${ci}-${ri}`}
                        style={{
                          width: '56px',
                          height: '56px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '32px',
                          borderRadius: '10px',
                          background: isSpinning
                            ? 'linear-gradient(145deg, #1A1A2E, #0D0D1A)'
                            : `linear-gradient(145deg, ${symbolColor}20, ${symbolColor}10)`,
                          border: isWinning
                            ? `3px solid ${symbolColor}`
                            : `2px solid ${isSpinning ? 'rgba(255, 215, 0, 0.3)' : `${symbolColor}50`}`,
                          boxShadow: isWinning
                            ? `0 0 20px ${symbolColor}, inset 0 0 10px ${symbolColor}30`
                            : `0 0 10px ${symbolColor}30`,
                          animation: isWinning ? 'winPulse 0.4s ease infinite' :
                                     isSpinning ? 'symbolSpin 0.08s linear infinite' : 'none',
                          filter: isWinning ? `drop-shadow(0 0 8px ${symbolColor})` : 'none',
                          transition: 'all 0.2s ease'
                        }}
                      >
                        {SYMBOL_ICONS[sym.id] || '❓'}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Win Display */}
      {lastWin > 0 && (
        <div style={{
          textAlign: 'center',
          marginBottom: '16px',
          animation: 'winPop 0.5s ease-out'
        }}>
          <div style={{
            fontSize: jackpotWon ? '36px' : bigWin ? '32px' : '28px',
            fontWeight: '900',
            background: jackpotWon
              ? 'linear-gradient(135deg, #FF1493, #FFD700, #00D9FF, #FFD700, #FF1493)'
              : 'linear-gradient(135deg, #FFD700, #FFA500, #FFD700)',
            backgroundSize: jackpotWon ? '300% 300%' : '200% auto',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            animation: jackpotWon ? 'rainbowGlow 0.5s ease infinite' : 'goldShine 2s linear infinite',
            filter: 'drop-shadow(0 0 20px rgba(255, 215, 0, 0.8))'
          }}>
            {jackpotWon ? 'JACKPOT! ' : bigWin ? 'BIG WIN! ' : ''}₱{lastWin.toLocaleString()}
          </div>
        </div>
      )}

      {message && (
        <p style={{
          textAlign: 'center',
          color: jackpotWon || bigWin ? '#FFD700' : '#00D9FF',
          fontSize: '14px',
          margin: '8px 0 16px',
          fontWeight: '600'
        }}>
          {message}
        </p>
      )}

      {/* Bet Controls */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '16px',
        marginBottom: '16px',
        padding: '12px',
        background: 'rgba(255, 255, 255, 0.05)',
        borderRadius: '12px',
        border: '1px solid rgba(255, 215, 0, 0.2)'
      }}>
        <button
          onClick={() => setBet(Math.max(Number(game.min_bet), bet - Number(game.min_bet)))}
          disabled={spinning}
          style={{
            width: '44px',
            height: '44px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #FFD700, #B8860B)',
            border: 'none',
            color: '#1A1A2E',
            fontSize: '24px',
            fontWeight: '900',
            cursor: spinning ? 'not-allowed' : 'pointer',
            opacity: spinning ? 0.5 : 1
          }}
        >
          -
        </button>
        <div style={{ textAlign: 'center', minWidth: '100px' }}>
          <div style={{ fontSize: '10px', color: '#888', textTransform: 'uppercase' }}>Bet</div>
          <div style={{ fontSize: '24px', fontWeight: '900', color: '#FFD700' }}>₱{bet}</div>
        </div>
        <button
          onClick={() => setBet(Math.min(Number(game.max_bet), bet + Number(game.min_bet)))}
          disabled={spinning || bet + Number(game.min_bet) > balance}
          style={{
            width: '44px',
            height: '44px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #FFD700, #B8860B)',
            border: 'none',
            color: '#1A1A2E',
            fontSize: '24px',
            fontWeight: '900',
            cursor: (spinning || bet + Number(game.min_bet) > balance) ? 'not-allowed' : 'pointer',
            opacity: (spinning || bet + Number(game.min_bet) > balance) ? 0.5 : 1
          }}
        >
          +
        </button>
      </div>

      {/* Quick Bet Chips */}
      <div style={{
        display: 'flex',
        gap: '8px',
        justifyContent: 'center',
        marginBottom: '16px',
        flexWrap: 'wrap'
      }}>
        {quickBets
          .filter(v => v >= Number(game.min_bet) && v <= Number(game.max_bet))
          .map(v => (
            <button
              key={v}
              onClick={() => setBet(v)}
              disabled={spinning || v > balance}
              style={{
                padding: '8px 16px',
                borderRadius: '20px',
                background: bet === v
                  ? 'linear-gradient(135deg, #FFD700, #B8860B)'
                  : 'rgba(255, 215, 0, 0.1)',
                border: bet === v ? '2px solid #FFF' : '2px solid rgba(255, 215, 0, 0.5)',
                color: bet === v ? '#1A1A2E' : '#FFD700',
                fontSize: '13px',
                fontWeight: '700',
                cursor: (spinning || v > balance) ? 'not-allowed' : 'pointer',
                opacity: spinning ? 0.5 : 1
              }}
            >
              ₱{v}
            </button>
          ))}
      </div>

      {/* Spin Button */}
      <div style={{ textAlign: 'center', marginBottom: '16px' }}>
        <button
          onClick={spin}
          disabled={spinning || balance < bet || balance <= 0}
          style={{
            width: '120px',
            height: '120px',
            borderRadius: '50%',
            background: spinning
              ? 'linear-gradient(145deg, #333, #222)'
              : (balance < bet || balance <= 0)
                ? 'linear-gradient(145deg, #333, #222)'
                : 'linear-gradient(145deg, #FFD700, #FFA500, #FFD700)',
            border: (spinning || balance < bet || balance <= 0) ? '4px solid #444' : '5px solid rgba(255, 255, 255, 0.3)',
            color: (spinning || balance < bet || balance <= 0) ? '#666' : '#1A1A2E',
            fontSize: '18px',
            fontWeight: '900',
            cursor: (spinning || balance < bet || balance <= 0) ? 'not-allowed' : 'pointer',
            boxShadow: spinning
              ? 'none'
              : '0 0 30px rgba(255, 215, 0, 0.6), inset 0 0 20px rgba(255, 255, 255, 0.2)',
            transition: 'all 0.3s ease',
            textTransform: 'uppercase',
            letterSpacing: '2px',
            animation: spinning ? 'spinPulse 0.3s ease infinite' : 'none'
          }}
        >
          {spinning ? '...' : 'SPIN'}
        </button>
      </div>

      {/* Free Spins Button */}
      {freeSpins > 0 && (
        <button
          onClick={useFreeSpin}
          disabled={spinning}
          style={{
            width: '100%',
            padding: '14px',
            background: 'linear-gradient(135deg, #00D9FF, #0099CC)',
            border: 'none',
            borderRadius: '12px',
            color: '#0D0D1A',
            fontSize: '14px',
            fontWeight: '800',
            cursor: spinning ? 'not-allowed' : 'pointer',
            textTransform: 'uppercase',
            letterSpacing: '1px',
            marginBottom: '16px',
            opacity: spinning ? 0.5 : 1
          }}
        >
          Free Spin ({freeSpins} left)
        </button>
      )}

      {/* Paytable Toggle */}
      <button
        onClick={() => setShowPaytable(!showPaytable)}
        style={{
          width: '100%',
          padding: '12px',
          background: 'rgba(255, 255, 255, 0.05)',
          border: '1px solid rgba(255, 215, 0, 0.2)',
          borderRadius: '12px',
          color: '#FFD700',
          fontSize: '14px',
          fontWeight: '600',
          cursor: 'pointer'
        }}
      >
        {showPaytable ? '▲ Hide Paytable' : '▼ Show Paytable'}
      </button>

      {/* Paytable */}
      {showPaytable && (
        <div style={{
          marginTop: '12px',
          padding: '16px',
          background: 'rgba(255, 255, 255, 0.03)',
          borderRadius: '12px',
          border: '1px solid rgba(255, 215, 0, 0.1)'
        }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '12px',
            fontSize: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '20px' }}>👑</span>
              <span style={{ color: '#888' }}>Wild - Substitutes all</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '20px' }}>💎</span>
              <span style={{ color: '#888' }}>3+ Scatter = Free Spins</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '20px' }}>7️⃣</span>
              <span style={{ color: '#888' }}>Highest payout</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '20px' }}>🔔</span>
              <span style={{ color: '#888' }}>Bonus multiplier</span>
            </div>
          </div>
        </div>
      )}

      {/* Low Balance Warning */}
      {balance <= 0 && (
        <div style={{
          marginTop: '16px',
          padding: '12px',
          background: 'rgba(255, 71, 87, 0.1)',
          border: '1px solid #FF4757',
          borderRadius: '12px',
          textAlign: 'center',
          color: '#FF4757',
          fontSize: '13px',
          fontWeight: '600'
        }}>
          No balance! <span onClick={() => navigate('/wallet')} style={{ color: '#FFD700', cursor: 'pointer', textDecoration: 'underline' }}>Deposit</span> to play.
        </div>
      )}

      {/* Styles */}
      <style>{`
        @keyframes symbolSpin {
          0% { transform: translateY(-10px); opacity: 0.3; }
          50% { transform: translateY(0); opacity: 1; }
          100% { transform: translateY(10px); opacity: 0.3; }
        }
        @keyframes winPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.08); }
        }
        @keyframes goldShine {
          0% { background-position: 200% center; }
          100% { background-position: -200% center; }
        }
        @keyframes rainbowGlow {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes spinPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        @keyframes winPop {
          0% { transform: scale(0); opacity: 0; }
          50% { transform: scale(1.2); }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
}

// Confetti component
function Confetti() {
  const colors = ['#FFD700', '#FF1493', '#00D9FF', '#FFA500', '#FF69B4', '#FFF'];
  const confetti = Array.from({ length: 60 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 2,
    color: colors[Math.floor(Math.random() * colors.length)],
    size: 6 + Math.random() * 10,
    duration: 2 + Math.random() * 2
  }));

  return (
    <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 9999 }}>
      {confetti.map(c => (
        <div
          key={c.id}
          style={{
            position: 'absolute',
            left: `${c.left}%`,
            top: '-20px',
            width: c.size,
            height: c.size,
            backgroundColor: c.color,
            borderRadius: Math.random() > 0.5 ? '50%' : '2px',
            animation: `confetti ${c.duration}s ease-out forwards`,
            animationDelay: `${c.delay}s`
          }}
        />
      ))}
      <style>{`
        @keyframes confetti {
          0% { transform: translateY(0) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
}